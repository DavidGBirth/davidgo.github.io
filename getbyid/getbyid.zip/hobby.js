
var x = document.getElementById("photo");
x.src = "photo.jpeg"
document.getElementById("name").innerHTML = "Nome: David Gomes Nascimento";
document.getElementById("age").innerHTML = "Idade: 23 anos";
document.getElementById("state").innerHTML = "Estado: Rio de Janeiro";

document.getElementById("title2").innerHTML = "Idiomas";
document.getElementById("description").innerHTML = "Eu adoro aprender idiomas ou, pelo menos, conhecer um pouco delas. Eu sempre pesquiso o alfabeto (se tiver um diferente do latino), depois aprendo os pronomes pessoais, como conjugar verbos e depois vou tentando aumentar meu vocabulário e meu conhecimento de gramática.";

document.getElementById("title3").innerHTML = "Referências";
document.getElementById("eng").innerHTML = "https://www.youtube.com/c/ShawenglishOnline";
document.getElementById("eng").href = "https://www.youtube.com/c/ShawenglishOnline";
x = "https://www.youtube.com/c/SpanishwithVicente";
document.getElementById("es").href = x;
document.getElementById("es").innerHTML = x;
document.getElementById("jp").innerHTML = "https://www.youtube.com/c/JapaneseAmmowithMisa";
document.getElementById("jp").href = "https://www.youtube.com/c/JapaneseAmmowithMisa";
document.getElementById("fr").innerHTML = "https://www.youtube.com/c/innerFrench";
document.getElementById("fr").href = "https://www.youtube.com/c/innerFrench";
document.getElementById("de").innerHTML = "https://www.youtube.com/c/EasyGerman";
document.getElementById("de").href = "https://www.youtube.com/c/EasyGerman";

document.getElementById("title4").innerHTML = "Meus idiomas preferidos"